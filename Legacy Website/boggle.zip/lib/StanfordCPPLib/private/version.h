#ifndef _version_h
#define _version_h

#define STANFORD_CPP_LIB_VERSION "2014/07/10 1:15pm"

#endif
