
#include "Boggle.h"
#include "bogglegui.h"

// letters on all 6 sides of every cube
static string CUBES[16] = {
    "AAEEGN", "ABBJOO", "ACHOPS", "AFFKPS",
    "AOOTTW", "CIMOTU", "DEILRX", "DELRVY",
    "DISTTY", "EEGHNW", "EEINSU", "EHRTVW",
    "EIOSST", "ELRTTY", "HIMNQU", "HLNNRZ"
};

// letters on every cube in 5x5 "Big Boggle" version (extension)
static string BIG_BOGGLE_CUBES[25] = {
    "AAAFRS", "AAEEEE", "AAFIRS", "ADENNN", "AEEEEM",
    "AEEGMU", "AEGMNN", "AFIRSY", "BJKQXZ", "CCNSTW",
    "CEIILT", "CEILPT", "CEIPST", "DDLNOR", "DDHNOT",
    "DHHLOR", "DHLNOR", "EIIITT", "EMOTTT", "ENSSSU",
    "FIPRSY", "GORRVW", "HIPRRY", "NOOTUW", "OOOTTU"
};

Boggle::Boggle(Lexicon& dictionary, string boardText) {
    board.resize(4,4);
    wordBank = dictionary;
    BoggleGUI::initialize(board.numRows(), board.numCols());
    if(boardText == "") {
        generateRandomBoard();
    } else {
        createBoard(boardText);
    }
}


void Boggle::createBoard(string boardText) {
    int textIndex = 0;
    for(int rows = 0; rows < board.numRows(); rows++) {
        for(int cols = 0; cols < board.numCols(); cols++) {
            board[rows][cols] = boardText[textIndex];
            BoggleGUI::labelCube(rows, cols, board[rows][cols]);
            textIndex++;
        }
    }
}


void Boggle::generateRandomBoard() {
    const int NUMSIDES = 5; //counting from zero
    int cubeIndex = 0;
    shuffle(CUBES, 16);
    for(int rows = 0; rows < board.numRows(); rows++) {
        for(int cols = 0; cols < board.numCols(); cols++) {
            board[rows][cols] = CUBES[cubeIndex][randomInteger(0, NUMSIDES)];
            BoggleGUI::labelCube(rows, cols, board[rows][cols]);
            cubeIndex++;
        }
    }
}

char Boggle::getLetter(int row, int col) {
    if(row < 0 || row > board.nRows) {
        throw row;
    } else if (col < 0 || col > board.nCols) {
        throw col;
    }
    return board[row][col];
}


bool Boggle::checkWord(string word) {
    if(word.length() < 4 || !wordBank.contains(word) || humanWords.contains(word)) {
        return false;
    }
    return true;
}


bool Boggle::humanWordSearch(string word) {
    BoggleGUI::clearHighlighting();
    for(int rows = 0; rows < board.numRows(); rows++) {
        for(int cols = 0; cols < board.numCols(); cols++) {
            if(board[rows][cols] == word[0]) {
                BoggleGUI::setHighlighted(rows, cols, true);
                BoggleGUI::setAnimationDelay(100);
                BoggleGUI::setHighlighted(rows, cols, false);
                if(humanWordSearchHelper(word, rows, cols, 1)) {
                    BoggleGUI::setHighlighted(rows, cols, true);
                    return true;
                }
            }
        }
    }
    return false;
}


bool Boggle::humanWordSearchHelper(string wordWanted, int row, int col, int index) {
    if(index == wordWanted.size()) {
        return true;
    }
    for (int nr = row - 1; nr <= row + 1; nr++) {
        for (int nc = col - 1; nc <= col + 1; nc++) {
            if(board.inBounds(nr, nc)) {
                if(!(nr == row && nc == col)){
                    if(wordWanted[index] == board[nr][nc]) {
                        index += 1;
                        BoggleGUI::setHighlighted(nr, nc, true);
                        BoggleGUI::setAnimationDelay(100);
                        BoggleGUI::setHighlighted(nr, nc, false);
                        if(humanWordSearchHelper(wordWanted, nr, nc, index)) {
                            BoggleGUI::setHighlighted(nr, nc, true);
                            return true;
                        }
                        index -= 1;
                    }
                }
            }
        }
    }
    return false;
}


int Boggle::humanScore() {
    int score = 0;
    for(string s: humanWords) {
        score += s.length() - 3;
    }
    return score;
}


Set<string> Boggle::computerWordSearch() {
    Set<string> result;
    HashSet<Point> visited;
    string word = "";
    for(int rows = 0; rows <= board.numRows(); rows++) {
        for(int cols = 0; cols <= board.numCols(); cols++) {
            visited.add(Point(rows, cols));
            computerWordSearchHelper(rows, cols, word, result, visited);
            visited.remove(Point(rows, cols));
        }
    }
    return result;
}


void Boggle::computerWordSearchHelper(int rows, int cols, string& word, Set<string>& result, HashSet<Point> visited) {
    if(!wordBank.containsPrefix(word)) {
        return;
    } else {
        for (int nr = rows - 1; nr <= rows + 1; nr++) { // needs to not count itself
            for (int nc = cols - 1; nc <= cols + 1; nc++) {
                if(!(nr == rows && nc == cols)){
                    if(checkWord(word)) {
                        result.add(word);
                    }
                    if(board.inBounds(nr, nc) && !visited.contains(Point(nr,nc))){
                        visited.add(Point(nr, nc));
                        word += board[nr][nc];
                        if(wordBank.containsPrefix(word)) {
                            computerWordSearchHelper(nr, nc, word, result, visited);
                        }
                        word = word.substr(0, word.size() - 1);
                        visited.remove(Point(nr, nc));
                    }
                }
            }
        }
    }
    return;
}


int Boggle::getScoreComputer() {
    int score = 0;
    for(string s: computerWordSearch()) {
        score += s.length() - 3;
    }
    return score;
}


Grid<char> Boggle::getBoard() {
    return board;
}


HashSet<string> Boggle::getHumanWords() {
    return humanWords;
}


void Boggle::addHumanWords(string word) {
    humanWords.add(word);
}


ostream& operator<<(ostream& out, Boggle& boggle) {
    Grid<char> b = boggle.getBoard();
    for(int rows = 0; rows < b.nRows; rows++) {
        for(int cols = 0; cols < b.nCols; cols++) {
            out << b[rows][cols];
        }
        out << endl;
    }
    return out;
}
