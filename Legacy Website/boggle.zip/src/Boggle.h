/*
 * Name: William Cheng
 * Course: CS 106B
 * Sources: Data example from class, all backtracking lectures, Piazza forums
 * Function: This Class contains all the functions necessary to run the majority of the GUI.
 * Additionally, it contains all the functions to run the game as well holds the game state.
 */
#ifndef _boggle_h
#define _boggle_h

#include <iostream>
#include <string>
#include "lexicon.h"
#include "point.h"
#include "random.h"
#include "shuffle.h"
#include "hashset.h"
#include "grid.h"
using namespace std;

class Boggle {
public:
    /*
     * Parameters: Takes a Lexicon dictionary by reference, and a string boardText
     * Return: none
     * Preconditions: The Lexicond contains an english dictionary, and the boardText is valid and not empty.
     * Function: intializes the GUI, creates/resizes the board, and creates its own private variable of the dictionary.
     */
    Boggle(Lexicon& dictionary, string boardText = "");

    /*
     * Parameters: The row and column of the letter you want
     * Return: a char which is the letter you want
     * Preconditions: row and column are not less than 0, row and column are not greater than the size of the board respectively.
     * Function: throws integer exceptions if the row and column don't match the above restrictions,
     * also gives you the character you were looking for.
     * ALT Fuction Description: breaks your program if someone gives nefarious inputs. (I think)
     */
    char getLetter(int row, int col);

    /*
     * Parameters: a string of the word you wish to check.
     * Return: true if the word checks, false otherwise.
     * Preconditions: none
     * Function: checks the following:
     * a.) the word is greater than 3 characters
     * b.) the word is found in the dictionary
     * c.) it hasn't already been found by the human.
     */
    bool checkWord(string word);

    /*
     * Parameters: a string, word that you wish to check.
     * Return: true if the word is found within the board.
     * Preconditions: a board exists and a GUI is initialized.
     * Function: checks if you can create the word from the board.
     */
    bool humanWordSearch(string word);

    /*
     * Parameters: none
     * Return: returns the human's score as an int
     * Precondition: the HashSet humanWords has already been checked for duplicates and incorrect words.
     * Function: returns the human's score
     */
    int humanScore();

    /*
     * Parameters: none
     * Return: The Computer's score as an int
     * Preconditions: same as computerWordSearch()
     * Function: compute the Computers score and returns it.
     */
    int getScoreComputer();

    /*
     * Parameters: none
     * Return: The resultant Set of strings of words of all the leftover words that can be created from the board.
     * Preconditions: none
     * Function: To iterate over the board and search for all the words that can be found. Returns the
     * words in a Set of strings.
     */
    Set<string> computerWordSearch();

    /*
     * Parameters: none
     * Return: a HashSet of strings of all the words found by the Human player.
     * Preconditions: none
     * Function: returns set of human words.
     */
    HashSet<string> getHumanWords();

    /*
     * Parameters: the word you wish to add to the set humanWords
     * Return: none
     * Preconditions: none
     * Function: adds a string to humanWords.
     */
    void addHumanWords(string word);

    /*
     * Parameters: none
     * Return: the board as a Grid of chars.
     * Preconditions: none
     * Function: returns the class's board.
     */
    Grid<char> getBoard();

private:
    /*
     * Parameters: none
     * Return: none
     * Preconditions: has access to constant and the board.
     * Function: Fills the board with pseudo-random letters coming from each respective die.
     */
    void generateRandomBoard();

    /*
     * Parameters: Takes a string boardText
     * Return: none
     * Preconditions: boardText is valid and not empty.
     * Function: takes the string boardText from the constructor and formats the string to the board.
     */
    void createBoard(string boardText);

    /*
     * Parameters: the rows and cols of the board, the word that will be placed in the set,
     * a reference to the Set of results, a HashSet of points to list all points of the board
     * the computer has been to.
     * Return: none
     * Preconditions: you are already iterating over the rows and the columns.
     * Function: serves to help computerWordSearch() by iterating over the neighbors and checking around.
     */
    void computerWordSearchHelper(int rows, int cols, string& word, Set<string>& result, HashSet<Point> visited);

    /*
     * Parameters: wordWanted: the word you wish to check, row: the row, col: the col, index: the index
     * Return: a boolean if it finds the character it wants
     * Preconditions: first letter has been checked
     * Function: helps the HumanWordSearch function do its thing.
     */
    bool humanWordSearchHelper(string wordWanted, int row, int col, int index);

    Grid<char> board; // Boggle's board, stores the char values of the 4x4 board.
    HashSet<string> humanWords; // stores words found by the player.
    Lexicon wordBank; // the dictionary used to check words.
};

/*
 * Parameters: ostream& by reference, the class by reference.
 * Return: ostream&
 * Preconditions: none.
 * Function: when called prints out the board in a 4x4 grid.
 */
ostream& operator<<(ostream& out, Boggle& boggle);

#endif // _boggle_h
