/*
 * Name: William Cheng
 * Course: CS 106B
 * Sources: Data example from class, all backtracking lectures, Piazza forums, Cplusplus.com
 * Function: Runs the console UI and all the user input.
 */
#include "lexicon.h"
#include "Boggle.h"
#include "simpio.h"
#include "strlib.h"
#include <regex.h>
#include "bogglegui.h"

void printGrid(Grid<char> board);
bool isValid(string layout);
void recordWordComputer(Set<string> results);

/*
 * Parameters: Lexicon passed by reference.
 * Return: none
 * Preconditions: the lexicon passed contains all the words from the dictionary.
 * Function: deals with user input and deals with the majority of User Interface.
 */
void playOneGame(Lexicon& dictionary) {
    string layout;
    if(getYesOrNo("Do you want to generate a random board?")) {
        layout = "";
    } else {
        while(!isValid(layout)) {
            layout = toUpperCase(getLine("Type the 16 letters to appear on the board:"));
            if(!isValid(layout)) {
                cout << "That is not a valid 16-letter board string. Try again." << endl;
                BoggleGUI::setStatusMessage("That is not a valid 16-letter board string. Try again.");
            }
        }
    }
    Boggle b1(dictionary, layout);
    string input = "a";
    cout << b1;
    while(input != "") {
        cout << "Your words (" << b1.getHumanWords().size() << "): " << b1.getHumanWords() << endl;
        cout << "Your score: " << b1.humanScore() << endl;
        input = toUpperCase(getLine("Type a word (or Enter to stop): "));
        if(input == "") {
            break;
        }
        if(b1.checkWord(input)){
            if(b1.humanWordSearch(input)) {
                b1.addHumanWords(input);
                cout << "You found a new word! '" << input << "'" << endl;
                BoggleGUI::setStatusMessage("You found a new word!");
                BoggleGUI::recordWord(input, BoggleGUI::HUMAN);
                BoggleGUI::setScore(b1.humanScore(), BoggleGUI::HUMAN);
                cout << b1;
            } else {
                cout << "That word can't be formed on this board." << endl;
                BoggleGUI::setStatusMessage("That word can't be formed on this board.");
            }
        } else {
            cout << "You must enter an unfound 4+ letter word from the dictionary." << endl;
            BoggleGUI::setStatusMessage("You must enter an unfound 4+ letter word from the dictionary");
        }
    }
    cout << "It's my turn!" << endl;
    cout << "My words (" << b1.computerWordSearch().size() << "): " << b1.computerWordSearch() << endl;
    cout << "My score: " << b1.getScoreComputer() << endl;
    recordWordComputer(b1.computerWordSearch());
    BoggleGUI::setScore(b1.getScoreComputer(), BoggleGUI::COMPUTER);
    if(b1.humanScore() >= b1.getScoreComputer()) {
        cout << "WOW, you defeated me! Congratulations!" << endl;
        BoggleGUI::setStatusMessage("WOW, you defeated me! Congratulations!");
    } else {
        cout << "Ha ha ha, I destroyed you. Better luck next time, puny human!" << endl;
        BoggleGUI::setStatusMessage("Ha ha ha, I destroyed you. Better luck next time, puny human!");
    }
}

/*
 * Parameters: takes the board text you wish to check for validity
 * Return: true if board text is valid, false otherwise
 * Preconditions: none
 * Function: checks to see if the string is valid for being put into a grid.
 */
bool isValid(string layout) {
    if(layout.size() != 16) {
        return false;
    }
    for(char c : layout) { // checks if the string layout in only made up of capital letters.
        if (c != 'A' && c != 'B' && c != 'C' && c != 'D' && c != 'E' && c != 'F' && c != 'G'
                && c != 'H' && c != 'I' && c != 'J' && c != 'K' && c != 'L' && c != 'M' && c != 'N'
                && c != 'O' && c != 'P' && c != 'Q' && c != 'R' && c != 'S' && c != 'T' && c != 'U'
                && c != 'V' && c != 'W' && c != 'X' && c != 'Y' && c != 'Z') {
            return false;
        }
    }
    return true;
}

/*
 * Parameters: takes the Computer words found
 * Return: none
 * Preconditions: GUI is instantialized
 * Function: GUI records the words of all the strings in the Set.
 */
void recordWordComputer(Set<string> results) {
    for(string str : results) {
        BoggleGUI::recordWord(str, BoggleGUI::COMPUTER);
    }
}
