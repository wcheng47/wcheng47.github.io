/*
 * Name: William Cheng
 * Course: CS 106B
 * Sources: Examples from Class.
 * Function: houses various trail finding algorithms and one maze generating algorithm using
 * kruskal's algorithm. The trail finding algorithms are as such
 * Depth First Search: uses recursive backtracking to find a path between vertices
 * Breadth First Search: finds the shortest path between vertices
 * Dijkstra's algorithm: finds the shortest path between vertices, includes edge cost
 * A* Search: uses a heuristic function to estimate and find the shortest path between vertices.
 * Usually quicker than Dijkstra's algorithm.
 */

#include "costs.h"
#include "trailblazer.h"
#include "queue.h"
#include "stack.h"
#include "pqueue.h"
#include "hashset.h"

bool depthFirstSearchHelper(BasicGraph& graph, Vertex* start, Vertex* end, Vector<Vertex*>& path);

using namespace std;

/*
 * Parameters: Takes a graph by reference, a start pointer, and an end pointer.
 * Return: returns the path as a Vector of vertices
 * Preconditions: parameters aren't junk.
 * Function: calls its helper function to recursively search through the maze. Wrapper function.
 */
Vector<Vertex*> depthFirstSearch(BasicGraph& graph, Vertex* start, Vertex* end) {
    graph.resetData();
    Vector<Vertex*> path;
    depthFirstSearchHelper(graph, start, end, path);
    return path;
}

/*
 * Parameters: takes the graph by reference, the start pointer, the end pointer, and a Vector of Vertices by reference
 * Return: returns a bool that describes whether the recursive function found the end point.
 * Preconditions: parameters aren't junk.
 * Function: recursively searches through the maze/graph for the start and end points
 */
bool depthFirstSearchHelper(BasicGraph& graph, Vertex* start, Vertex* end, Vector<Vertex*>& path) {
    path.add(start);
    start->setColor(GREEN);
    start->visited = true;
    if (start == end) {
        return true;
    }
    for(Vertex* v : graph.getNeighbors(start)) {
        if(v->visited == false) {
            v->setColor(YELLOW);
            if(depthFirstSearchHelper(graph, v, end, path)) {
                return true;
            }
        }
    }
    start->setColor(GRAY);
    path.remove(path.size() - 1);
    return false;
}

/*
 * Parameters: Takes the graph by reference, the start position, and the end position.
 * Return: returns the path as a Vector of vertices.
 * Preconditions: parameters aren't junk.
 * Function: searches through the surrounding neighbors until it hits the end vertex.
 * returns the fastest path from start to end. Does not including edge cost.
 */
Vector<Vertex*> breadthFirstSearch(BasicGraph& graph, Vertex* start, Vertex* end) {
    graph.resetData();
    Vector<Vertex*> path;
    Queue<Vertex*> vertices;
    vertices.enqueue(start);
    start->setColor(YELLOW);
    start->visited = true;
    while(!vertices.isEmpty()) {
        Vertex* v;
        v = vertices.dequeue();
        v->setColor(GREEN);
        if (v == end) {
            Stack<Vertex*> temp;
            while (v != start) {
                temp.push(v);
                v = v->previous;
            }
            temp.push(start);
            while(!temp.isEmpty()) {
                path.add(temp.pop());
            }
            return path;
        }
        for(Vertex* n : graph.getNeighbors(v)) {
            if(n->visited == false)
            {
                n->setColor(YELLOW);
                n->visited = true;
                n->previous = v;
                vertices.enqueue(n);
            }
        }
    }
    return path;
}

/*
 * Parameters: takes the graph by reference, the start pointer, and the end pointer.
 * Return: returns the path as a Vector of vertices
 * Preconditions: parameters aren't junk.
 * Function: searches through the neighbors searching for the fastest path including edge cost.
 * checks cheapest ways from one end to the other.
 */
Vector<Vertex*> dijkstrasAlgorithm(BasicGraph& graph, Vertex* start, Vertex* end) {
    graph.resetData();
    Vector<Vertex*> path;
    Set<Vertex*> initializer;
    PriorityQueue<Vertex*> vertices;
    initializer = graph.getVertexSet();
    for(Vertex* v : initializer) {
        v->cost = POSITIVE_INFINITY;
    }
    start->cost = 0;
    vertices.enqueue(start, start->cost);
    start->setColor(YELLOW);
    while(!vertices.isEmpty()) {
        Set<Vertex*> contains;
        contains.add(start);
        Vertex* v = vertices.dequeue();
        v->setColor(GREEN);
        v->visited = true;
        if(v == end) {
            Stack<Vertex*> temp;
            while (v != start) {
                temp.push(v);
                v = v->previous;
            }
            temp.push(start);
            while(!temp.isEmpty()) {
                path.add(temp.pop());
            }
            return path;
        }
        for(Vertex* n : graph.getNeighbors(v)) {
            if(n->visited == false) {
                double cost = v->cost + graph.getEdge(v,n)->cost;
                if(cost < n->cost) {
                    n->cost = cost;
                    n->previous = v;
                    if(contains.contains(n)) {
                        vertices.changePriority(n, n->cost);
                    } else {
                        vertices.enqueue(n, n->cost);
                        n->setColor(YELLOW);
                        contains.add(n);
                    }
                }
            }
        }
    }
    return path;
}

/*
 * Parameters: takes the graph by reference, the start pointer, and the end pointer.
 * Return: returns the path as a Vector of vertices
 * Preconditions: parameters aren't junk.
 * Function: Adds a Heuristic Function to dijkstra's algorithm to help it find a path more efficiently.
 */
Vector<Vertex*> aStar(BasicGraph& graph, Vertex* start, Vertex* end) {
    graph.resetData();
    Vector<Vertex*> path;
    Set<Vertex*> initializer;
    PriorityQueue<Vertex*> vertices;
    initializer = graph.getVertexSet();
    for(Vertex* v : initializer) {
        v->cost = POSITIVE_INFINITY;
    }
    start->cost = 0;
    vertices.enqueue(start, heuristicFunction(start, end));
    start->setColor(YELLOW);
    while(!vertices.isEmpty()) {
        Set<Vertex*> contains;
        contains.add(start);
        Vertex* v = vertices.dequeue();
        v->setColor(GREEN);
        v->visited = true;
        if(v == end) {
            break;
        }
        for(Vertex* n : graph.getNeighbors(v)) {
            if(n->visited == false) {
                double cost = v->cost + graph.getEdge(v,n)->cost;
                if(cost < n->cost) {
                    n->cost = cost;
                    n->previous = v;
                    if(contains.contains(n)) {
                        vertices.changePriority(n, heuristicFunction(n, end) + cost);
                    } else {
                        vertices.enqueue(n, heuristicFunction(n, end) + cost);
                        n->setColor(YELLOW);
                        contains.add(n);
                    }
                }
            }
        }
    }
    Stack<Vertex*> temp;
    while(end != start)
    {
        temp.push(end);
        end = end->previous;
    }
    temp.push(start);
    while(!temp.isEmpty()) {
        path.add(temp.pop());
    }
    return path;
}

/*
 * Parameters: takes the graph by reference.
 * Return: returns a set of edges to be made into a maze.
 * Preconditions: graph is real.
 * Function: is given a graph and links the edges together to make it a spanning tree.
 * is used in other code to turn into a maze.
 */
Set<Edge*> kruskal(BasicGraph& graph) {
    Set<Edge*> mst;
    Set<Vertex*> vertices;
    PriorityQueue<Edge*> edges;
    Vector<Set<Vertex*>> cluster;
    mst = graph.getEdgeSet();
    while(!mst.isEmpty()) {
        edges.enqueue(mst.first(), mst.first()->cost);
        mst.remove(mst.first());
    }
    vertices = graph.getVertexSet();
    while(!vertices.isEmpty()) {
        Set<Vertex*> temp;
        temp.add(vertices.first());
        cluster.add(temp);
        vertices.remove(vertices.first());
    }
        while(cluster.size() > 2) {
            Edge* e = edges.dequeue();
            int tempOneIndex;
            int tempTwoIndex;
            Set<Vertex*> merged;
            for(int i = 0 ; i < cluster.size(); i++) {
                if(cluster.get(i).contains(e->start))
                {
                    tempOneIndex = i;
                }
                if(cluster.get(i).contains(e->finish))
                {
                    tempTwoIndex = i;
                }
            }
            if(tempOneIndex != tempTwoIndex) {
                merged = cluster.get(tempOneIndex) + cluster.get(tempTwoIndex);
                if(tempOneIndex > tempTwoIndex) {
                    cluster.remove(tempOneIndex);
                    cluster.remove(tempTwoIndex);
                } else {
                    cluster.remove(tempTwoIndex);
                    cluster.remove(tempOneIndex);
                }
                cluster.add(merged);
                mst.add(e);
            }
        }
    return mst;
}
